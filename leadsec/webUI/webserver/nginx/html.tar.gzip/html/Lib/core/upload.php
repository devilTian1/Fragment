<?php
    abstract class UPLOAD {

	abstract public function upload();

    }
?>
