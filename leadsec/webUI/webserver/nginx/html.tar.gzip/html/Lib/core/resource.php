<?php
    /**
     *
     */
    abstract class RESOURCE {
        
        abstract public function getAddr();
        
        abstract public function getAddrList();

        abstract public function getTimeList();
        
        abstract public function getRoleList();
    
        abstract public function getInterface();
    }
?>
