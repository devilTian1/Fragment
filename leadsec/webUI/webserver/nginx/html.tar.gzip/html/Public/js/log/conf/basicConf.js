function basicConfBtn() {
    if($('#basicConfForm').valid()){
        ajaxSubmitForm($('#basicConfForm'), '设置基本配置 ');
    }
}
