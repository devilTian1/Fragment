function setDns() {
    if($('#setDnsForm').valid()){
        ajaxSubmitForm($('#setDnsForm'), '设置域名服务器 ');
    }
}