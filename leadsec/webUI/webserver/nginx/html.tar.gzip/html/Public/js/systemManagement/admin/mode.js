function modifyMode() {
    ajaxSubmitForm($('#modeForm'), '设置管理方式');
}
